1:"$Sreact.fragment"
2:I[32035,["/_next/static/chunks/6e9ac5b86215ad1c.js","/_next/static/chunks/c585a01853f8100b.js"],"default"]
3:I[91168,["/_next/static/chunks/6e9ac5b86215ad1c.js","/_next/static/chunks/c585a01853f8100b.js"],"default"]
0:{"buildId":"5LE-Dh5fL3cOVuBqwYPbE","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
