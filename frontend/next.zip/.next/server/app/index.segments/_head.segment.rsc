1:"$Sreact.fragment"
2:I[64381,["/_next/static/chunks/6e9ac5b86215ad1c.js","/_next/static/chunks/c585a01853f8100b.js"],"ViewportBoundary"]
3:I[64381,["/_next/static/chunks/6e9ac5b86215ad1c.js","/_next/static/chunks/c585a01853f8100b.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"5LE-Dh5fL3cOVuBqwYPbE","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Looma Dashboard - School Management System"}],["$","meta","1",{"name":"description","content":"Monitor and manage Looma devices across schools in Nepal"}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"loading":null,"isPartial":false}
