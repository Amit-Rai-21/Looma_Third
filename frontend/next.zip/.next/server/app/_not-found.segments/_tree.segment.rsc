:HL["/_next/static/chunks/03c53205d29f1c56.css","style"]
:HL["/_next/static/chunks/349aaba073ae71a9.css","style"]
0:{"buildId":"5LE-Dh5fL3cOVuBqwYPbE","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"/_not-found","paramType":null,"paramKey":"/_not-found","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
