globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/a1451473d9bc4458.js",
    "static/chunks/9a3c864c13c19766.js",
    "static/chunks/5b7309ed332ccfdf.js",
    "static/chunks/8fe0db191ae685d3.js",
    "static/chunks/turbopack-06d61aceb86e4d2c.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];