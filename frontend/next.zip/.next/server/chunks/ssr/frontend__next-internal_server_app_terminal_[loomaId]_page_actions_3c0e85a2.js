module.exports=[16806,(a,b,c)=>{}];

//# sourceMappingURL=frontend__next-internal_server_app_terminal_%5BloomaId%5D_page_actions_3c0e85a2.js.map